var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/compare-analysis.js
var compare_analysis_exports = {};
__export(compare_analysis_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(compare_analysis_exports);
async function handler(event, context) {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const { currentAnalysis, previousAnalysis } = JSON.parse(event.body);
    if (!currentAnalysis || !previousAnalysis) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Missing analysis data" })
      };
    }
    const comparison = compareAnalyses(currentAnalysis, previousAnalysis);
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(comparison)
    };
  } catch (error) {
    console.error("Comparison error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Comparison failed",
        message: error.message
      })
    };
  }
}
function compareAnalyses(current, previous) {
  const improvements = [];
  const declined = [];
  const stable = [];
  const currentMetrics = {};
  const previousMetrics = {};
  current.metrics.forEach((m) => {
    currentMetrics[m.name] = m;
  });
  previous.metrics.forEach((m) => {
    previousMetrics[m.name] = m;
  });
  Object.keys(currentMetrics).forEach((metricName) => {
    const currentMetric = currentMetrics[metricName];
    const previousMetric = previousMetrics[metricName];
    if (previousMetric) {
      const scoreDiff = currentMetric.score - previousMetric.score;
      const percentChange = Math.round(scoreDiff / previousMetric.score * 100);
      const comparison = {
        name: metricName,
        icon: currentMetric.icon,
        category: currentMetric.category,
        currentScore: currentMetric.score,
        previousScore: previousMetric.score,
        scoreDiff,
        percentChange,
        currentSeverity: currentMetric.severity || 0,
        previousSeverity: previousMetric.severity || 0,
        severityDiff: (previousMetric.severity || 0) - (currentMetric.severity || 0),
        status: scoreDiff > 2 ? "improved" : scoreDiff < -2 ? "declined" : "stable"
      };
      if (scoreDiff > 2) {
        improvements.push(comparison);
      } else if (scoreDiff < -2) {
        declined.push(comparison);
      } else {
        stable.push(comparison);
      }
    }
  });
  const overallScoreDiff = current.overallScore - previous.overallScore;
  const overallPercentChange = Math.round(overallScoreDiff / previous.overallScore * 100);
  const skinAgeDiff = current.skinAge && previous.skinAge ? previous.skinAge - current.skinAge : 0;
  let overallStatus = "stable";
  if (overallScoreDiff > 3) overallStatus = "improved";
  else if (overallScoreDiff < -3) overallStatus = "declined";
  const recommendations = generateRecommendations(declined);
  return {
    success: true,
    comparison: {
      overall: {
        status: overallStatus,
        currentScore: current.overallScore,
        previousScore: previous.overallScore,
        scoreDiff: overallScoreDiff,
        percentChange: overallPercentChange
      },
      skinAge: {
        current: current.skinAge,
        previous: previous.skinAge,
        diff: skinAgeDiff,
        description: skinAgeDiff > 0 ? `Tu piel luce ${skinAgeDiff} a\xF1os m\xE1s joven \u{1F389}` : skinAgeDiff < 0 ? `Tu piel luce ${Math.abs(skinAgeDiff)} a\xF1os mayor` : "Tu edad de piel se mantiene estable"
      },
      improvements: improvements.sort((a, b) => b.percentChange - a.percentChange),
      declined: declined.sort((a, b) => a.percentChange - b.percentChange),
      stable,
      summary: {
        totalMetrics: Object.keys(currentMetrics).length,
        improved: improvements.length,
        declined: declined.length,
        stable: stable.length,
        improvementRate: Math.round(improvements.length / Object.keys(currentMetrics).length * 100)
      },
      recommendations,
      timeBetween: calculateTimeBetween(previous.timestamp, current.timestamp),
      currentAnalysisId: current.analysisId,
      previousAnalysisId: previous.analysisId
    }
  };
}
function generateRecommendations(declined) {
  const recommendations = [];
  declined.forEach((metric) => {
    switch (metric.category) {
      case "wrinkles":
        recommendations.push({
          metric: metric.name,
          recommendation: "Usar productos con retinol y aplicar protector solar diario",
          priority: metric.severityDiff > 2 ? "high" : "medium"
        });
        break;
      case "eyes":
        recommendations.push({
          metric: metric.name,
          recommendation: "Aplicar crema de ojos con cafe\xEDna y dormir 7-8 horas",
          priority: metric.severityDiff > 2 ? "high" : "medium"
        });
        break;
      case "texture":
        recommendations.push({
          metric: metric.name,
          recommendation: "Exfoliar 2-3 veces por semana y usar niacinamida",
          priority: metric.severityDiff > 2 ? "high" : "medium"
        });
        break;
      case "hydration":
        recommendations.push({
          metric: metric.name,
          recommendation: "Beber m\xE1s agua y usar \xE1cido hialur\xF3nico",
          priority: metric.severityDiff > 2 ? "high" : "medium"
        });
        break;
      case "sensitivity":
        recommendations.push({
          metric: metric.name,
          recommendation: "Evitar productos con fragancias y usar ingredientes calmantes",
          priority: metric.severityDiff > 2 ? "high" : "medium"
        });
        break;
      case "spots":
        recommendations.push({
          metric: metric.name,
          recommendation: "Usar vitamina C y protector solar SPF 50+",
          priority: metric.severityDiff > 2 ? "high" : "medium"
        });
        break;
      case "oil":
        recommendations.push({
          metric: metric.name,
          recommendation: "Usar productos oil-free y limpiar el rostro 2 veces al d\xEDa",
          priority: metric.severityDiff > 2 ? "high" : "medium"
        });
        break;
    }
  });
  return recommendations;
}
function calculateTimeBetween(previousTimestamp, currentTimestamp) {
  const previous = new Date(previousTimestamp);
  const current = new Date(currentTimestamp);
  const diffMs = current - previous;
  const days = Math.floor(diffMs / (1e3 * 60 * 60 * 24));
  const hours = Math.floor(diffMs % (1e3 * 60 * 60 * 24) / (1e3 * 60 * 60));
  if (days > 0) {
    return {
      days,
      hours,
      description: `Hace ${days} ${days === 1 ? "d\xEDa" : "d\xEDas"}${hours > 0 ? ` y ${hours} ${hours === 1 ? "hora" : "horas"}` : ""}`
    };
  } else {
    return {
      days: 0,
      hours,
      description: `Hace ${hours} ${hours === 1 ? "hora" : "horas"}`
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
